<!-- Data table -->
<link href="<?php echo base_url('assets/data-table/datatable_bootstrap.css') ?>" rel="stylesheet" media="screen">
<script src="<?php echo base_url('assets/data-table/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/data-table/dataTables.bootstrap.js') ?>"></script>
<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	/* Init DataTables */
	// $('#example').dataTable();
	// $('.datatable').dataTable();
} );
</script>