<script src="<?php echo base_url('assets/drag-n-drop/js/jquery.js') ?>"></script>
<script src="<?php echo base_url('assets/drag-n-drop/js/jqueryUI.js') ?>"></script>
<script src="<?php echo base_url('assets/drag-n-drop/js/cookie.js') ?>"></script>
<script src="<?php echo base_url('assets/drag-n-drop/js/jsfunctions.js') ?>"></script>