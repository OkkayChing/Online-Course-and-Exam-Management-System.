<script src="<?php echo base_url('assets/datepicker/moment.min.js') ?>"></script>
<script src="<?php echo base_url('assets/datepicker/daterangepicker.js') ?>"></script>
<link href="<?php echo base_url('assets/datepicker/daterangepicker.css') ?>" rel="stylesheet" media="screen">
