<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,700italic,400,300,600,700' rel='stylesheet' type='text/css'>
<!-- Bootstrap core CSS -->
<link href="<?php echo base_url('assets/bootstrap/css/bootstrap.css') ?>" rel="stylesheet" media="screen">

<!-- Font Awesome -->
<link href="<?php echo base_url('assets/font-awesome/css/font-awesome.min.css') ?>" rel="stylesheet" media="screen">

<!-- Custom CSS  -->
<link href="<?php echo base_url('assets/css/front.css') ?>" rel="stylesheet" media="screen">
<!--<link href="<?php //echo base_url('assets/css/custom.css') ?>" rel="stylesheet" media="screen"> -->
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script src="<?php echo base_url('assets/js/jquery-2.0.3.min.js') ?>"></script>
<!-- <script src="<?php echo base_url('assets/js/video.js') ?>"></script> -->
