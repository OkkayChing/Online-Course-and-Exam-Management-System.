<!------------- Ban Confirmation ---------------> 
<script type="text/javascript">
    function ban_confirmation(user)
    {
        return confirm('Are You Really Want to Banned "' +user+'" ?');
    }
    function deactivate_confirmation(user)
    {
        return confirm('Are You Really Want to Deactivate "' +user+'" ?');
    }
</script>    