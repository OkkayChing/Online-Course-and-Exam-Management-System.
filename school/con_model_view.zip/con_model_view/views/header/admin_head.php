<!-- Bootstrap core CSS -->
<link href="<?php echo base_url('assets/bootstrap/css/bootstrap.css') ?>" rel="stylesheet" media="all">

<!-- Font Awesome -->
<link href="<?php echo base_url('assets/font-awesome/css/font-awesome.min.css') ?>" rel="stylesheet" media="all">

<!-- Custom CSS  -->
<link href="<?php echo base_url('assets/css/style.css') ?>" rel="stylesheet" media="screen">
<!-- AJAX loading -->
<script src="<?php echo base_url('assets/js/face.js') ?>"></script>
<link href="<?php echo base_url('assets/css/process.css') ?>" rel="stylesheet" media="screen">
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script src="<?php echo base_url('assets/js/jquery-2.0.3.min.js') ?>"></script>
<!-- Custom JS  -->
<script src="<?php echo base_url('assets/js/jsscript.js') ?>"></script>
<script src="<?php echo base_url('assets/js/video_admin.js') ?>"></script>
        
<!-- Admin core CSS -->
<link href="<?php echo base_url('assets/css/admin.css') ?>" rel="stylesheet" media="screen">

<!------------- Delete Confirmation ---------------> 
<script type="text/javascript">
    function delete_confirmation() {
        return confirm('Do you really want to delete the data?');
    }
</script>    
